/**
 * fuck hexo
 * 找半天都没有插入变量的功能
 * 注册新功能用的脚本，不懂
*/
/* 
'use strict';

hexo.extend.tag.register('variable', function(args){
    console.log("------------------variable---------------------");
    console.log(hexo.config.url)
    console.log(hexo.config.data.iOS)
    // return `<img src="` + args[0] + `" />`;
    console.log(args[0])
    return ``+hexo.config.data.iOS;
  });
   */